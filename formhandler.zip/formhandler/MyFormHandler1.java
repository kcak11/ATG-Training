package test;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;

import atg.droplet.DropletException;
import atg.droplet.DropletFormException;
import atg.droplet.GenericFormHandler;
import atg.repository.Repository;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.ServletUtil;

public class MyFormHandler1  extends GenericFormHandler{

	//private String username;
//	private String age;
	
	private HashMap<String, String> value=new HashMap<String, String>();
	
	
	public HashMap<String, String> getValue() {
		return value;
	}
	public void setValue(HashMap<String, String> value) {
		this.value = value;
	}

	private FirstBean fbean;
	private Repository repository;
	private String successURL;
	
	public String getSuccessURL() {
		return successURL;
	}
	public void setSuccessURL(String successURL) {
		this.successURL = successURL;
	}
	public Repository getRepository() {
		return repository;
	}
	public void setRepository(Repository repository) {
		this.repository = repository;
	}
	public FirstBean getFbean() {
		return fbean;
	}
	public void setFbean(FirstBean fbean) {
		this.fbean = fbean;
	}
	/*
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
 */
	
	public String getValueFromMap(String key)
	{
		return value.get(key);
	}
	
	@Override
	public void beforeGet(DynamoHttpServletRequest request,
			DynamoHttpServletResponse response) {
		// TODO Auto-generated method stub
		super.beforeGet(request, response);
	}
	
	@Override
	public void afterGet(DynamoHttpServletRequest request,
			DynamoHttpServletResponse response) {
		// TODO Auto-generated method stub
		super.afterGet(request, response);
	}
	
	@Override
	public boolean beforeSet(DynamoHttpServletRequest request,
			DynamoHttpServletResponse response) throws DropletFormException {
		// TODO Auto-generated method stub
		return super.beforeSet(request, response);
	}
	
	@Override
	public boolean afterSet(DynamoHttpServletRequest arg0,
			DynamoHttpServletResponse arg1) throws DropletFormException {
		// TODO Auto-generated method stub
		return super.afterSet(arg0, arg1);
	}
	
	public boolean handleValidate(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		//do all the basic validations
		String username=getValueFromMap("username");
		String age=getValueFromMap("age");
		if(isLoggingDebug())
			logDebug("inside the handle validate method");
		
		if((username==null) || (username.length()<=3))
		{
			 addFormException(new DropletException("username is null or too small"));
			 if(isLoggingDebug())
					logDebug("username is null or too small");
				
		}
		int ageVal=-1;
		try{
		ageVal=Integer.parseInt(age);
		}catch(NumberFormatException nfe)
		{
			addFormException(new DropletException("age is not a valid integer"));
			if(isLoggingError())
				logError("age parsing error " + nfe.getMessage());			
		}
		
		if(!((ageVal >15) && (ageVal < 80)))
		{
			addFormException(new DropletException("age is not in range"));
			if(isLoggingDebug())
				logDebug("age not in range");
			
		}		
		if(getFormError())
			return true;
		
		if(isLoggingDebug())
			logDebug("now going to do the business logic");
		
		//FirstBean obj=new FirstBean();
		
	//	FirstBean obj=(FirstBean)
	//	ServletUtil.getCurrentRequest().resolveName("/dynamusic/FirstBean");
		
		FirstBean obj=getFbean();
		obj.setAge(ageVal);
		obj.setUsername(username);
		
		if(isLoggingDebug())
			logDebug("business logic is complete. redirect to success page");
		
		if(successURL!=null) {
			//pResponse.sendLocalRedirect(successURL, pRequest);
			redirectOrForward(pRequest, pResponse, successURL);
		}		
		
		return false;
	}
	
	public boolean handleTest(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		 
		return false;
	}
	
	
	
	
	
}
