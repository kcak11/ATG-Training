package dynamusic;

import javax.transaction.SystemException;
import javax.transaction.TransactionManager;

import atg.dtm.TransactionDemarcation;
import atg.dtm.TransactionDemarcationException;
import atg.nucleus.GenericService;
import atg.repository.MutableRepository;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;

public class SongsManager extends GenericService{

	Repository repository;
	TransactionManager transactionManager;

	public TransactionManager getTransactionManager() {
		return transactionManager;
	}

	public void setTransactionManager(TransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	public Repository getRepository() {
		if(isLoggingDebug())
			logDebug("Invoked SongsManager::getRepository");
		return repository;
	}

	public void setRepository(Repository repository) {
		if(isLoggingDebug())
			logDebug("Invoked SongsManager::setRepository");
		this.repository = repository;
	}
	
	public void deleteAlbumsByArtist(String pArtistId) throws RepositoryException{
		TransactionDemarcation td=new TransactionDemarcation();
		try{
			
		
		if(isLoggingDebug())
			logDebug("Invoked SongsManager::deleteAlbumsByArtist");
		MutableRepository songRepo=(MutableRepository)getRepository();
		RepositoryView albumView=songRepo.getView("album");
		RqlStatement findAlbums=RqlStatement.parseRqlStatement("artist.id=?0");
		Object[] params=new Object[1];
		params[0]=pArtistId;
		RepositoryItem[] albums=findAlbums.executeQuery(albumView, params);
		if(albums==null){
			if(isLoggingDebug())
				logDebug("albums is null -- hence returning");
			return;
		}
		if(isLoggingDebug()){
			logDebug("albums length: "+albums.length);
		}
		try{
		td.begin(getTransactionManager(),td.REQUIRED);
		for(int i=0;i<albums.length;i++){
			logDebug("albumid: "+albums[i].getRepositoryId());
			songRepo.removeItem(albums[i].getRepositoryId(), "album");
		}
		}catch(RepositoryException re){
			if(isLoggingError()){
				logError("Unable to delete albums::SongsManager.java");
			}
			try {
				getTransactionManager().setRollbackOnly();
			} catch (SystemException se) {
				if(isLoggingError())
					logError("Rollback has failed");
			}
		}finally{
			td.end();
		}
		
		}catch(TransactionDemarcationException tde){
			if(isLoggingError())
				logError("Transaction Demarcation Exception::SongsManager.java "+tde.getMessage());
		}
	}
	
}
