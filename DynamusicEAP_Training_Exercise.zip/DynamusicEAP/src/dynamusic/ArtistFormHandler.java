package dynamusic;

import java.io.IOException;

import javax.servlet.ServletException;

import atg.repository.RepositoryException;
import atg.repository.servlet.RepositoryFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

public class ArtistFormHandler extends RepositoryFormHandler{
	
	private SongsManager songsManager;

	public SongsManager getSongsManager() {
		return songsManager;
	}

	public void setSongsManager(SongsManager songsManager) {
		this.songsManager = songsManager;
	}
	
	
	@Override
	protected void preDeleteItem(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
			
		try{
			getSongsManager().deleteAlbumsByArtist(getRepositoryItem().getRepositoryId());
		}catch(RepositoryException re){
			if(isLoggingDebug())
				logDebug("Error in deleting artist . . .");
		}
		
		super.preDeleteItem(pRequest, pResponse);
	}

}
