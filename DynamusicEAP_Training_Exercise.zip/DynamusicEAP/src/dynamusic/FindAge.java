package dynamusic;

import java.util.Date;

import atg.repository.RepositoryItemImpl;
import atg.repository.RepositoryPropertyDescriptor;

public class FindAge extends RepositoryPropertyDescriptor{

	public static final String AGE_FORMAT_ATTR_NAME="ageFormat";
	
	private String mAgeFormat="years";
	
	/*public String getmAgeFormat() {
		return mAgeFormat;
	}

	public void setmAgeFormat(String mAgeFormat) {
		this.mAgeFormat = mAgeFormat;
	}*/

	@Override
	public void setValue(String pAttributeName, Object pValue) {
		// TODO Auto-generated method stub
		super.setValue(pAttributeName, pValue);
		if(AGE_FORMAT_ATTR_NAME.equals(pAttributeName) && pValue!=null){
//			setmAgeFormat(pValue.toString());
			mAgeFormat=pValue.toString();
		}
	}
	
	@Override
	public Object getPropertyValue(RepositoryItemImpl pItem, Object pValue) {
		// TODO Auto-generated method stub
		
		if(pValue!=null){
			return pValue;
		}
		
		Date dob=(Date)pItem.getPropertyValue("dateOfBirth");
		if("days".equals(mAgeFormat)){
			return new Integer(AgeCalc.ageInDays(dob));
		}else if("years".equals(mAgeFormat)){
			return new Integer(AgeCalc.ageInYears(dob));
		}
		
		return super.getPropertyValue(pItem, pValue);
	}
	

	@Override
	public boolean isQueryable() {
		return false;
	}
	
	@Override
	public boolean isWritable() {
		return false;
	}
	
}
