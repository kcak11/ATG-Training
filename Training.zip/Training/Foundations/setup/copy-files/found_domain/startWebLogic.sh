#!/bin/sh

# WARNING: This file is created by the Configuration Wizard.
# Any changes to this script may be lost when adding extensions to this configuration.

DOMAIN_HOME="c:/AE102/bea/user_projects/domains/found_domain"

${DOMAIN_HOME}/bin/startWebLogic.sh $*

