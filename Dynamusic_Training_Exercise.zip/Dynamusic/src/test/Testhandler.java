package test;

import java.lang.reflect.Field;

import atg.droplet.GenericFormHandler;
import atg.userprofiling.ProfileFormHandler;

public class Testhandler extends ProfileFormHandler{

	static public void main(String[] args){
		
		ProfileFormHandler pfh=new ProfileFormHandler();
		
		Field[] fields=GenericFormHandler.class.getDeclaredFields();  //ProfileFormHandler.class.getSuperclass().getSuperclass().getDeclaredMethods();
		System.out.println(ProfileFormHandler.class.getSuperclass().getSuperclass().getCanonicalName());
		for(int i=0;i<fields.length;i++){
			if(true || fields[i].getName().startsWith("get"))System.out.println(fields[i].getName());
		}
		
	}
	
	
}
