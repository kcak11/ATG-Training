package test;

import java.io.IOException;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
/*
 * <dsp:droplet name='FactorialDroplet'>
 * <dsp:param name='number' value='5'/>
 * <dsp:oparam name='notANumber'>
 * <B>You passed <dsp:valueof param='number'/> which  is not a valid number</B>
 * </dsp:oparam>
 * <dsp:oparam name='output'>
 *The factorial of  <dsp:valueof param='number'/> is 
 *		<B><dsp:valueof param='factorial'/></B>
 * </dsp:oparam>
 * </dsp:droplet>
 * 
 */
public class FactorialDroplet  extends DynamoServlet{
	@Override
	public void service(DynamoHttpServletRequest req,
			DynamoHttpServletResponse res) throws ServletException, IOException {
		if(isLoggingInfo())
			logInfo("inside the service method of the factorial droplet");		
		Object num=req.getObjectParameter("number");
		if(num instanceof Integer) 		{
			if(isLoggingDebug())
				logDebug("passed input is  a valid integer " + num);
			int fact=1;			
			int number=((Integer)num).intValue();			
			if((number < 0) || (number > 15)) {
				req.serviceLocalParameter("numberNotInRange", req, res);
				return;
			}			
			for(int i=1;i<=number;i++) 	{
				fact=fact*i;
			}
			req.setParameter("factorial", new Integer(fact));
			req.serviceLocalParameter("output", req, res);
			return;
		}
		else 	{
			if(isLoggingDebug())
				logDebug("passed input is not a valid integer");			
			//res.getWriter().println("<B>passed input is not a valid number</B>");
			req.serviceLocalParameter("notANumber", req, res);
			return;
		}		
	}	
}
